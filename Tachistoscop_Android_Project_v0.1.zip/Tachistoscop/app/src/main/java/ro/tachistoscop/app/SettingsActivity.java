package ro.tachistoscop.app;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private EditText contentInput;
    private Spinner modeSpinner;
    private Spinner fontSpinner;
    private SeekBar chunkSeek;
    private TextView chunkLabel;
    private LinearLayout chunkSection;
    private SeekBar fontSizeSeek;
    private TextView fontSizeLabel;
    private TextView preview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(58, 36, 23));
        getWindow().setNavigationBarColor(Color.rgb(42, 26, 16));
        buildUi();
        loadValues();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(239, 226, 199));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("SETĂRI TAHISTOSCOP");
        title.setTextColor(Color.rgb(61, 38, 24));
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        title.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        title.setPadding(0, 0, 0, dp(14));
        root.addView(title);

        addSectionLabel(root, "Conținut");
        TextView contentHelp = addHelp(root,
                "Mod listă: un cuvânt sau o sintagmă pe fiecare linie.\n" +
                "Mod text: aplicația împarte automat textul în blocuri de 1–6 cuvinte.");
        contentHelp.setPadding(0, 0, 0, dp(8));

        contentInput = new EditText(this);
        contentInput.setGravity(Gravity.TOP | Gravity.START);
        contentInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        contentInput.setTextColor(Color.rgb(35, 31, 27));
        contentInput.setHint("Exemplu:\nA DOUA MODIFICARE\npolitica externă\n1848");
        contentInput.setHintTextColor(Color.rgb(130, 115, 95));
        contentInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        contentInput.setMinLines(8);
        contentInput.setPadding(dp(12), dp(12), dp(12), dp(12));
        contentInput.setBackgroundColor(Color.rgb(251, 246, 233));
        root.addView(contentInput, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(230)));

        addSectionLabel(root, "Mod conținut");
        modeSpinner = new Spinner(this);
        String[] modes = {"Un element pe linie", "Împarte un text în blocuri"};
        modeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, modes));
        root.addView(modeSpinner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        chunkSection = new LinearLayout(this);
        chunkSection.setOrientation(LinearLayout.VERTICAL);
        chunkSection.setPadding(0, dp(8), 0, dp(4));
        chunkLabel = addHelp(chunkSection, "Cuvinte pe bloc: 3");
        chunkSeek = new SeekBar(this);
        chunkSeek.setMax(5);
        chunkSection.addView(chunkSeek, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(chunkSection);

        addSectionLabel(root, "Font");
        fontSpinner = new Spinner(this);
        String[] fonts = {"Serif — stil de carte", "Sans — simplu", "Monospace — cifre/cod", "Serif cursiv"};
        fontSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, fonts));
        root.addView(fontSpinner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        fontSizeLabel = addHelp(root, "Mărime font: 42");
        fontSizeSeek = new SeekBar(this);
        fontSizeSeek.setMax(50);
        root.addView(fontSizeSeek, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        addSectionLabel(root, "Previzualizare");
        preview = new TextView(this);
        preview.setText("A DOUA MODIFICARE");
        preview.setTextColor(Color.rgb(31, 27, 23));
        preview.setGravity(Gravity.CENTER);
        preview.setBackgroundColor(Color.rgb(250, 245, 231));
        preview.setPadding(dp(10), dp(18), dp(10), dp(18));
        root.addView(preview, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(120)));

        TextView mechanics = addHelp(root,
                "Mecanism: tragi mânerul, textul rămâne ascuns, iar la eliberare clapeta se deschide și se închide automat. " +
                "O tragere mai puternică produce o expunere mai scurtă. Nu există sunet și nu este necesar internetul.");
        mechanics.setPadding(0, dp(12), 0, dp(12));

        Button save = new Button(this);
        save.setText("SALVEAZĂ ȘI REVINO");
        save.setTextColor(Color.WHITE);
        save.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        save.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(100, 60, 35)));
        save.setOnClickListener(v -> saveAndFinish());
        root.addView(save, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        Button cancel = new Button(this);
        cancel.setText("ÎNAPOI FĂRĂ SALVARE");
        cancel.setTextColor(Color.rgb(72, 47, 31));
        cancel.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(221, 201, 164)));
        cancel.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        cancelLp.topMargin = dp(8);
        root.addView(cancel, cancelLp);

        modeSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> {
            chunkSection.setVisibility(position == 1 ? View.VISIBLE : View.GONE);
        }));

        chunkSeek.setOnSeekBarChangeListener(new SimpleSeekBarListener(progress -> {
            int words = progress + 1;
            chunkLabel.setText("Cuvinte pe bloc: " + words);
        }));

        fontSizeSeek.setOnSeekBarChangeListener(new SimpleSeekBarListener(progress -> {
            int size = progress + 22;
            fontSizeLabel.setText("Mărime font: " + size);
            updatePreview();
        }));

        fontSpinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> updatePreview()));

        setContentView(scroll);
    }

    private void loadValues() {
        contentInput.setText(AppPrefs.getRawText(this));
        modeSpinner.setSelection(AppPrefs.getMode(this));
        chunkSeek.setProgress(AppPrefs.getChunkWords(this) - 1);
        chunkLabel.setText("Cuvinte pe bloc: " + AppPrefs.getChunkWords(this));
        fontSpinner.setSelection(AppPrefs.getFontIndex(this));
        int size = Math.round(AppPrefs.getFontSizeSp(this));
        fontSizeSeek.setProgress(Math.max(0, Math.min(50, size - 22)));
        fontSizeLabel.setText("Mărime font: " + size);
        chunkSection.setVisibility(AppPrefs.getMode(this) == 1 ? View.VISIBLE : View.GONE);
        updatePreview();
    }

    private void updatePreview() {
        if (preview == null || fontSpinner == null || fontSizeSeek == null) return;
        int fontIndex = fontSpinner.getSelectedItemPosition();
        Typeface typeface;
        switch (fontIndex) {
            case 1:
                typeface = Typeface.SANS_SERIF;
                break;
            case 2:
                typeface = Typeface.MONOSPACE;
                break;
            case 3:
                typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC);
                break;
            default:
                typeface = Typeface.SERIF;
                break;
        }
        preview.setTypeface(typeface);
        preview.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSizeSeek.getProgress() + 22);
    }

    private void saveAndFinish() {
        AppPrefs.setRawText(this, contentInput.getText().toString());
        AppPrefs.setMode(this, modeSpinner.getSelectedItemPosition());
        AppPrefs.setChunkWords(this, chunkSeek.getProgress() + 1);
        AppPrefs.setFontIndex(this, fontSpinner.getSelectedItemPosition());
        AppPrefs.setFontSizeSp(this, fontSizeSeek.getProgress() + 22);
        AppPrefs.setCurrentIndex(this, 0);
        Toast.makeText(this, "Setări salvate", Toast.LENGTH_SHORT).show();
        finish();
    }

    private void addSectionLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextColor(Color.rgb(76, 47, 29));
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        label.setPadding(0, dp(16), 0, dp(6));
        root.addView(label);
    }

    private TextView addHelp(LinearLayout root, String text) {
        TextView help = new TextView(this);
        help.setText(text);
        help.setTextColor(Color.rgb(95, 78, 62));
        help.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        help.setLineSpacing(0f, 1.15f);
        root.addView(help);
        return help;
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }

    private interface PositionCallback {
        void onPosition(int position);
    }

    private static class SimpleItemSelectedListener implements android.widget.AdapterView.OnItemSelectedListener {
        private final PositionCallback callback;

        SimpleItemSelectedListener(PositionCallback callback) {
            this.callback = callback;
        }

        @Override
        public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
            callback.onPosition(position);
        }

        @Override
        public void onNothingSelected(android.widget.AdapterView<?> parent) { }
    }

    private interface ProgressCallback {
        void onProgress(int progress);
    }

    private static class SimpleSeekBarListener implements SeekBar.OnSeekBarChangeListener {
        private final ProgressCallback callback;

        SimpleSeekBarListener(ProgressCallback callback) {
            this.callback = callback;
        }

        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            callback.onProgress(progress);
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) { }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) { }
    }
}
