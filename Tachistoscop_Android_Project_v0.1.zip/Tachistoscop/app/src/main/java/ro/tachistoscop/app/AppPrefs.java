package ro.tachistoscop.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;

import java.util.ArrayList;
import java.util.List;

public final class AppPrefs {
    private static final String PREFS = "tachistoscop_prefs";
    private static final String KEY_TEXT = "content_text";
    private static final String KEY_MODE = "content_mode";
    private static final String KEY_CHUNK = "chunk_words";
    private static final String KEY_FONT = "font_family";
    private static final String KEY_FONT_SIZE = "font_size_sp";
    private static final String KEY_INDEX = "current_index";

    private static final String DEFAULT_TEXT =
            "TACHISTOSCOP\n" +
            "LECTURĂ RAPIDĂ\n" +
            "A DOUA MODIFICARE\n" +
            "1848\n" +
            "MEMORIE VIZUALĂ";

    private AppPrefs() { }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String getRawText(Context context) {
        return prefs(context).getString(KEY_TEXT, DEFAULT_TEXT);
    }

    public static void setRawText(Context context, String value) {
        prefs(context).edit().putString(KEY_TEXT, value == null ? "" : value).apply();
    }

    public static int getMode(Context context) {
        return prefs(context).getInt(KEY_MODE, 0);
    }

    public static void setMode(Context context, int mode) {
        prefs(context).edit().putInt(KEY_MODE, mode).apply();
    }

    public static int getChunkWords(Context context) {
        return Math.max(1, Math.min(6, prefs(context).getInt(KEY_CHUNK, 3)));
    }

    public static void setChunkWords(Context context, int words) {
        prefs(context).edit().putInt(KEY_CHUNK, Math.max(1, Math.min(6, words))).apply();
    }

    public static int getFontIndex(Context context) {
        return prefs(context).getInt(KEY_FONT, 0);
    }

    public static void setFontIndex(Context context, int index) {
        prefs(context).edit().putInt(KEY_FONT, Math.max(0, Math.min(3, index))).apply();
    }

    public static float getFontSizeSp(Context context) {
        return Math.max(22f, Math.min(72f, prefs(context).getFloat(KEY_FONT_SIZE, 42f)));
    }

    public static void setFontSizeSp(Context context, float size) {
        prefs(context).edit().putFloat(KEY_FONT_SIZE, Math.max(22f, Math.min(72f, size))).apply();
    }

    public static int getCurrentIndex(Context context) {
        return Math.max(0, prefs(context).getInt(KEY_INDEX, 0));
    }

    public static void setCurrentIndex(Context context, int index) {
        prefs(context).edit().putInt(KEY_INDEX, Math.max(0, index)).apply();
    }

    public static Typeface getTypeface(Context context) {
        switch (getFontIndex(context)) {
            case 1:
                return Typeface.SANS_SERIF;
            case 2:
                return Typeface.MONOSPACE;
            case 3:
                return Typeface.create(Typeface.SERIF, Typeface.ITALIC);
            case 0:
            default:
                return Typeface.SERIF;
        }
    }

    public static List<String> getStimuli(Context context) {
        String raw = getRawText(context).trim();
        List<String> result = new ArrayList<>();
        if (raw.isEmpty()) {
            return result;
        }

        if (getMode(context) == 0) {
            String[] lines = raw.split("\\r?\\n");
            for (String line : lines) {
                String clean = line.trim().replaceAll("\\s+", " ");
                if (!clean.isEmpty()) {
                    result.add(clean);
                }
            }
        } else {
            String[] words = raw.replaceAll("\\s+", " ").trim().split(" ");
            int chunk = getChunkWords(context);
            for (int i = 0; i < words.length; i += chunk) {
                StringBuilder builder = new StringBuilder();
                for (int j = i; j < Math.min(words.length, i + chunk); j++) {
                    if (builder.length() > 0) builder.append(' ');
                    builder.append(words[j]);
                }
                if (builder.length() > 0) result.add(builder.toString());
            }
        }
        return result;
    }
}
